<?php
//Turn on error reporting
ini_set('display_errors', 'On');

//Connect to the database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","durborae-db", "PWgRGSAxhs1hgcrH","durborae-db");
if($mysqli->connect_errno){
    echo "Connection error " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Log or Return a Source</title>
</head>
<body>

<div>
    <table>
        <tr>
            <td>Sources Currently Checked Out</td>
        </tr>
        <tr>
            <td>Record ID</td>
            <td>Issuing Last Name</td>
            <td>Issuing First Name</td>
            <td>Check Out Date</td>
            <td>Location</td>
            <td>Source</td>
        </tr>
        <?php
        if(!($stmt = $mysqli->prepare("SELECT r.R_ID, r.fname, r.lname, r.iss_date, l.loc_name, s.S_ID, r.ret_date FROM Record r INNER JOIN location l ON l.L_ID = r.L_ID INNER JOIN s_Source s ON s.S_ID = r.S_ID WHERE s.checked_out =1 AND r.ret_date IS NULL "))){
            echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
        }

        if(!$stmt->execute()){
            echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
        }
        if(!$stmt->bind_result($rid, $fname, $lname, $iss_date, $loc_name, $sid, $retdate)){
            echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
        }
        while($stmt->fetch()){
            echo "<tr>\n<td>\n" . $rid . "\n</td>\n<td>\n" . $lname . "\n</td>\n<td>\n" . $fname . "\n</td>\n<td>\n" . $iss_date . "\n</td>\n<td>\n" . $loc_name . "\n</td>\n<td>\n" . $sid . "\n</td>\n</tr>\n";
        }
        $stmt->close();
        ?>
    </table>
</div>

<form method="post" action="returnsource.php">
    <fieldset>
        <legend>Log Entry</legend>
        <p>Date in: <input type="date" name="indate"></p>
        <p>Source ID:
            <select name="SID">
                <?php
                if(!($stmt = $mysqli->prepare("SELECT S_ID FROM s_Source WHERE checked_out =1"))){
                    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
                }

                if(!$stmt->execute()){
                    echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                if(!$stmt->bind_result($sid)){
                    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                while($stmt->fetch()){
                    echo '<option value=" '. $sid . ' "> ' . $sid . '</option>\n';
                }
                $stmt->close();

                ?>
            </select>
        </p>
        <input type="submit">
    </fieldset>
</form>

<a href="/~durborae/DBproject/index.html">home</a>
</body>
</html>

<?php
if(!($stmt = $mysqli->prepare("UPDATE Record SET ret_date = ? WHERE S_ID= ?"))){
    echo "Prepare failed: " . $stmt->errno . " " . $stmt->error;
}
if(!($stmt->bind_param("si",$_POST['indate'], $_POST['SID']))){
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
} else {
    //echo "Added " . $stmt->affected_rows . " rows to location.";
}
$sql = 'UPDATE s_Source SET checked_out = 0 WHERE S_ID=' . $_POST['SID'];

if ($mysqli->query($sql) === TRUE) {
    echo "\"<meta http-equiv=\"refresh\" content=\"1;url=/~durborae/DBproject/returnsource.php/\">\"\n";
} else {
    //echo "Error updating record: " . $mysqli->error;
}
?>