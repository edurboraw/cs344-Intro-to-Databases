<?php
//Turn on error reporting
ini_set('display_errors', 'On');

//Connect to the database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","durborae-db", "PWgRGSAxhs1hgcrH","durborae-db");
if($mysqli->connect_errno){
    echo "Connection error " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Insert a new record</title>
</head>
<body>

<form method="post" action="editsource.php">
    <fieldset>
        <legend>Add Isotopes</legend>
        <p>Source#:
            <select name="SID">
                <?php
                if(!($stmt = $mysqli->prepare("SELECT S_ID FROM s_Source"))){
                    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
                }

                if(!$stmt->execute()){
                }
                if(!$stmt->bind_result($sid)){
                    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                while($stmt->fetch()){
                    echo '<option value=" '. $sid . ' "> ' . $sid . '</option>\n';
                }
                $stmt->close();

                ?>
            </select>
        </p>
        <p>Isotope to Add:
            <select name="isotope">
                <?php
                if(!($stmt = $mysqli->prepare("SELECT C_ID, element, atomic_mass FROM isotope"))){
                    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
                }

                if(!$stmt->execute()){
                }
                if(!$stmt->bind_result($cid, $element, $amass)){
                    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                while($stmt->fetch()){
                    echo '<option value=" '. $cid . ' "> ' . $element . "-" . $amass . '</option>\n';
                }
                $stmt->close();

                ?>
            </select>
        </p>
        <p><input type="submit" /></p>
    </fieldset>
</form>
<br>
<a href="index.html">Return Home</a>

</body>
</html>

<?php
if(!($stmt = $mysqli->prepare("INSERT INTO source_comp (fk_S_ID, fk_C_ID) VALUES (?,?)"))){
    echo "Prepare failed: " . $stmt->errno . " " . $stmt->error;
}
if(!($stmt->bind_param("ii",$_POST['SID'], $_POST['isotope']))){
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){

} else {
    echo "Added " . $stmt->affected_rows . " rows to location.";
}
?>