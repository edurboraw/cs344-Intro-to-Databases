<?php
//Turn on error reporting
ini_set('display_errors', 'On');

//Connect to the database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","durborae-db", "PWgRGSAxhs1hgcrH","durborae-db");
if($mysqli->connect_errno){
    echo "Connection error " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}

if(!($stmt = $mysqli->prepare("INSERT INTO s_Source (activity, s_geometry, state, manufactured, checked_out) VALUES (?,?,?,?,0)"))){
    echo "Prepare failed: " . $stmt->errno . " " . $stmt->error;
}
if(!($stmt->bind_param("dsss",$_POST['activity'], $_POST['geometry'], $_POST['state'], $_POST['manufactured']))){
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
} else {
    echo "Added " . $stmt->affected_rows . " rows to location.";
}
?>

<!DOCTYPE html>
<html lang="en">
<body>
    <br>
    <a href="index.html">Menu</a><br>
    <a href="editsource.php">Add Isotopes</a><br>
</body>


