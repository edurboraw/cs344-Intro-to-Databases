<?php
//Turn on error reporting
ini_set('display_errors', 'On');

//Connect to the database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","durborae-db", "PWgRGSAxhs1hgcrH","durborae-db");
if($mysqli->connect_errno){
    echo "Connection error " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Log or Return a Source</title>
</head>
<body>
<form method="post" action="viewsource.php">
    <fieldset>
        <legend>Select Source Number to See Information</legend>
        <p>Source ID:
            <select name="SID">
                <?php
                if(!($stmt = $mysqli->prepare("Select S_ID FROM s_Source"))){
                    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
                }

                if(!$stmt->execute()){
                    echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                if(!$stmt->bind_result($sid)){
                    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                while($stmt->fetch()){
                    echo '<option value=" '. $sid . ' "> ' . $sid . '</option>\n';
                }
                $stmt->close();

                ?>
            </select>
        </p>
        <input type="submit">
    </fieldset>
</form>

        <div>
            <table>
                <tr>
                    <td>Source Data</td>
                </tr>
                <tr>
                    <td>Source ID</td>
                    <td>Activity(mCi)</td>
                    <td>Geometry</td>
                    <td>Physical State</td>
                    <td>Manufactured Date</td>
                    <td>Isotope</td>
                </tr>
                <?php
                if(!($stmt = $mysqli->prepare("Select s.S_ID, s.activity, s.s_geometry, s.state, s.manufactured, i.element, i.atomic_mass FROM s_Source s INNER JOIN source_comp cp on cp.fk_S_ID = s.S_ID INNER JOIN isotope i ON i.C_ID = cp.fk_C_ID WHERE S_ID=?"))){
                    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
                }
                if(!($stmt->bind_param("i", $_POST['SID']))){
                    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
                }
                if(!$stmt->execute()){
                    echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                if(!$stmt->bind_result($sid, $activity, $s_geometry, $state, $manufactured, $element, $amass)){
                    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                while($stmt->fetch()){
                    echo "<tr>\n<td>\n" . $sid . "\n</td>\n<td>\n" . $activity . "\n</td>\n<td>\n" . $s_geometry . "\n</td>\n<td>\n" . $state . "\n</td>\n<td>\n" . $manufactured . "\n</td>\n<td>\n" . $element.$amass . "\n</td>\n</tr>\n";
                }
                echo "<br> <a href='index.html'>Home</a> ";
                $stmt->close();
                ?>
            </table>
        </div>
</body>
</html>
