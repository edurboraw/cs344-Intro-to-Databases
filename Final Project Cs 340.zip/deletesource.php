<<?php
//Turn on error reporting
ini_set('display_errors', 'On');

//Connect to the database
$mysqli = new mysqli("oniddb.cws.oregonstate.edu","durborae-db", "PWgRGSAxhs1hgcrH","durborae-db");
if($mysqli->connect_errno){
    echo "Connection error " . $mysqli->connect_errno . " " . $mysqli->connect_error;
}
if($_POST['yesno']==yes) {
    if (!($stmt = $mysqli->prepare("DELETE FROM s_Source where S_ID =?"))) {
        echo "Prepare failed: " . $stmt->errno . " " . $stmt->error;
    }
    if (!($stmt->bind_param("i", $_POST['SID']))) {
        echo "Bind failed: " . $stmt->errno . " " . $stmt->error;
    }
    if (!$stmt->execute()) {
        echo "Execute failed: " . $stmt->errno . " " . $stmt->error;
    } else {
        echo "Added " . $stmt->affected_rows . " rows to location.";
    }
}
else{
    echo "You choose not to delete the source\n";
    echo "<a href='index.html'>Home</a>";
}
?>