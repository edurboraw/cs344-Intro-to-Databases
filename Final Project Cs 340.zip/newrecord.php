<?php
    //Turn on error reporting
    ini_set('display_errors', 'On');

    //Connect to the database
    $mysqli = new mysqli("oniddb.cws.oregonstate.edu","durborae-db", "PWgRGSAxhs1hgcrH","durborae-db");
    if($mysqli->connect_errno){
        echo "Connection error " . $mysqli->connect_errno . " " . $mysqli->connect_error;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Insert a new record</title>
</head>
<body>

<form method="post" action="newrecord.php">
    <fieldset>
        <legend>Log Entry</legend>
        <p>First Name: <input type="text" name="fname"> </p>
        <p>Last Name: <input type="text" name="lname"> </p>
        <p>Date Out: <input type="date" name="odate"></p>
        <p>Location: <select name="local">
                <?php
                if(!($stmt = $mysqli->prepare("SELECT L_ID, loc_name FROM location"))){
                    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
                }

                if(!$stmt->execute()){
                   // echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                if(!$stmt->bind_result($lid, $localname)){
                    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                while($stmt->fetch()){
                    echo '<option value=" '. $lid . ' "> ' . $localname . '</option>\n';
                }
                $stmt->close();

                ?>
            </select>
        </p>
        <p>Source ID:
            <select name="SID">
                <?php
                if(!($stmt = $mysqli->prepare("Select S_ID FROM s_Source WHERE checked_out = 0"))){
                    echo "Prepare failed: "  . $stmt->errno . " " . $stmt->error;
                }

                if(!$stmt->execute()){
                   // echo "Execute failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                if(!$stmt->bind_result($sid)){
                    echo "Bind failed: "  . $mysqli->connect_errno . " " . $mysqli->connect_error;
                }
                while($stmt->fetch()){
                    echo '<option value=" '. $sid . ' "> ' . $sid . '</option>\n';
                }
                $stmt->close();

                ?>
            </select>
        </p>
        <input type="submit">
    </fieldset>
</form>
<a href="http://web.engr.oregonstate.edu/~durborae/DBproject/index.html">Home</a>
</body>
</html>

<?php
if(!($stmt = $mysqli->prepare("INSERT INTO Record (fname, lname, iss_date, L_ID, S_ID) VALUES (?,?,?,?,?)"))){
    echo "Prepare failed: " . $stmt->errno . " " . $stmt->error;
}
if(!($stmt->bind_param("sssii",$_POST['fname'], $_POST['lname'], $_POST['odate'], $_POST['local'], $_POST['SID']))){
    echo "Bind failed: "  . $stmt->errno . " " . $stmt->error;
}
if(!$stmt->execute()){
    //echo "Execute failed: "  . $stmt->errno . " " . $stmt->error;
} else {
    echo "Added " . $stmt->affected_rows . " rows to location.";
}
$sql = 'UPDATE s_Source SET checked_out = 1 WHERE S_ID=' . $_POST['SID'];

if ($mysqli->query($sql) === TRUE) {
    echo "\"<meta http-equiv=\"refresh\" content=\"1;url=/~durborae/DBproject/newrecord.php/\">\"\n";
} else {
    //echo "Error updating record: " . $mysqli->error;
}
?>